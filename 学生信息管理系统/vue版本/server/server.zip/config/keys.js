module.exports = {
  port: '6500',
  dbUrl: 'mongodb://localhost/student-message',
  secret: 'secret'
}