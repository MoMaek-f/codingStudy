# 学生接口
登录 /api/login 
方式：post

查询成绩 /api/achievement/:id
方式：get
传值_id

# 管理员
查询所有学生 